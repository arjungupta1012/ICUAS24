#!/bin/bash

# Set environment variables for X11 forwarding
export DISPLAY=$DISPLAY

# Run the Docker container with the specified options
docker run -it --rm\
    -e DISPLAY=$DISPLAY \
    -v /tmp/.X11-unix/:/tmp/.X11-unix \
    nishantchandna/scipts_2:latest /bin/bash
