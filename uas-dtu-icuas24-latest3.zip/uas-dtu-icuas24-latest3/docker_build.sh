#!/bin/bash

echo "Building uas-dtu docker image for icuas24 finals"

build_args=""


docker build \
    $build_args \
    -f Dockerfile \
    -t uas-dtu:icuas24 \
    .
