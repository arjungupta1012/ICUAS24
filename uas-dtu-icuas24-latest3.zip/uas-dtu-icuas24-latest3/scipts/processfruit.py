import numpy as np
import rospy
import cv2
import os
import sensor_msgs.point_cloud2 as pc2
import math
from std_msgs.msg import Header


fruit_details_y = []
fruit_details_r = []
count_r = 0
count_y = 0
threshold_x = 1.1
threshold_y = 1.1
threshold_z = 1.1

threshold_point = 17
threshold_point_red = 10
frame = 0

camera_image_send = None

def updateEntry(entry,fruit,display_data,count, thresholded_distances):
    entryy = entry
    entryy[3][0] = (entry[3][0]*entry[4] + fruit[2][0])/(entry[4]+1) 
    entryy[3][1] = (entry[3][1]*entry[4] + fruit[2][1])/(entry[4]+1)
    entryy[3][2] = (entry[3][2]*entry[4] + fruit[2][2])/(entry[4]+1) 
    entry[2] = fruit[1] 
    entry[5] = fruit[3]
    ed_from_existing = np.linalg.norm(thresholded_distances - entryy[3])
    if not np.any(ed_from_existing < 0.2):
        entry[4] += 1
        entry[3] = entryy[3]
        if entry[1] == '0':
            thresh = threshold_point
        else:
            thresh = threshold_point_red
        if entry[4] > thresh:
            if entry[0] == 0:
                count+=1
                entry[0] = count
                display_data.append([entry[0],entry[1],entry[2],camera_image_send])
    return display_data,count,entry

def updatetable(fruit,fruit_details,display_data,count):
    if fruit_details == []:
        fruit_details.append([0,fruit[0],fruit[1],fruit[2],1,fruit[3]])
    tracked_bool = False
    thresholded_bool = False
    thresholded_distances = []
    for entry in fruit_details:
        if entry[0] != 0:
            thresholded_distances.append([entry[3][0], entry[3][1], entry[3][2]])
        else:
            thresholded_distances.append([-1000, -1000 ,-1000])
    thresholded_distances = np.array(thresholded_distances)
            
    for entry in fruit_details:
        if entry[5] == fruit[3]:
           # if abs(entry[3][0] - fruit[2][0]) < threshold_x and abs(entry[3][1] - fruit[2][1]) < threshold_y  and abs(entry[3][2] - fruit[2][2]) < threshold_z:
            display_data,count,entry = updateEntry(entry,fruit,display_data,count, thresholded_distances)
            tracked_bool = True
 
            break
    if not tracked_bool :
        for entry in fruit_details:
            if entry[0]==0:
               # if abs(entry[3][0] - fruit[2][0]) < threshold_x and abs(entry[3][1] - fruit[2][1]) < threshold_y  and abs(entry[3][2] - fruit[2][2]) < threshold_z:
                    display_data,count,entry = updateEntry(entry,fruit,display_data,count, thresholded_distances)
                    #print("Getting thresholded")
                    thresholded_bool = True
                    break
                
            else:
                threshold_x_n = 0.65
                threshold_y_n = 0.65
                threshold_z_n = 0.65
                if abs(entry[3][0] - fruit[2][0]) < threshold_x_n and abs(entry[3][1] - fruit[2][1]) < threshold_y_n  and abs(entry[3][2] - fruit[2][2]) < threshold_z_n:
                    display_data,count,entry = updateEntry(entry,fruit,display_data,count, thresholded_distances)
                    thresholded_bool = True
                    break

    if not thresholded_bool and not tracked_bool:
        fruit_details.append([0,fruit[0],fruit[1],fruit[2],1,fruit[3]]) 
    
    return fruit_details,display_data,count
def updatefruit(fruit_details_y,fruit_details_r,fruits,count_y,count_r,display_data):
    for fruit in fruits:
        if fruit[0] == '0':
            fruit_details_y,display_data,count_y = updatetable(fruit,fruit_details_y,display_data,count_y)
        else:
            fruit_details_r,display_data,count_r = updatetable(fruit,fruit_details_r,display_data,count_r)    
    
    return fruit_details_y,fruit_details_r,count_y,count_r,display_data

def processing(global_coordinates,labels,camera_image):

    global count_r
    global count_y    
    global fruit_details_r
    global fruit_details_y
    
    fruits = []
    display_data = []
    global camera_image_send
    camera_image_send = camera_image
    
    for i in range(len(labels)):
        fruits.append([labels[i][0],labels[i][1],list(global_coordinates[i]),labels[i][2]])
    # Created variable fruits storing all current fruit details
    
    fruit_details_y,fruit_details_r,count_y,count_r,display_data = updatefruit(fruit_details_y,fruit_details_r,fruits,count_y,count_r,display_data)
    
    global frame
    if frame >= 4:
        for fruit in fruit_details_y:
            if fruit[4] <= 100 and fruit[0] == 0:
                fruit_details_y.remove(fruit)
        for fruit in fruit_details_r:
            if fruit[4] <= 100 and fruit[0] == 0:
                fruit_details_r.remove(fruit)
        frame = 0
    frame += 1
    
    return display_data,count_y,count_r
    
