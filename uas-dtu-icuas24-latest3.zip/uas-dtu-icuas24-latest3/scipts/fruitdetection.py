import numpy as np
import cv2
from cv_bridge import CvBridge, CvBridgeError
import rospy
from sensor_msgs.msg import Image

tracking_threshold = 30
previous_frames_fruits = [[] for _ in range(tracking_threshold)]
yellow_id_max = 0
red_id_max = 0
first_time = False
def detect_fruit(image_msg, model):
    global yellow_id_max, red_id_max
    global previous_frames_fruits, first_time
    centre_threshold = 15
    area_threshold = 200
    
    bridge = CvBridge()
    camera_image = None
    fruits = []

    # Convert image message to OpenCV format
    try:
        np_arr = np.frombuffer(image_msg.data, np.uint8)
        camera_image = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
    except Exception as e:
        print(e)
        
    # Process the image using the model
    if camera_image is not None:
        results = model.predict(camera_image, verbose=False, conf=0.67, iou=0.8)
    
    if results is None:
        return None, camera_image
    
    for r in results:
        boxes = r.boxes.xyxy
        cls = r.boxes.cls
        if boxes.shape[0] != 0:
            for i, coord in enumerate(boxes):
                x1, y1, x2, y2 = coord
                x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
                label = cls[i]
                label = int(label)
                label = str(label)
                fruits.append([label, x1, y1, x2, y2, None])  # Initialize ID as None

    # Assign IDs to fruits
    if not first_time:
        yellow_id = 0
        red_id = 0
        for i, fruit in enumerate(fruits):
            if int(fruit[0]) == 0:
                fruits[i][5] = yellow_id
                yellow_id += 1
            if int(fruit[0]) == 1:
                fruits[i][5] = red_id
                red_id += 1
        first_time = True

    combined_previous_fruits = []
    for frame_fruits in previous_frames_fruits:
        combined_previous_fruits.extend(frame_fruits)
        
    for i in range(len(fruits)):
        current_fruit_center = ((fruits[i][1] + fruits[i][3]) / 2, (fruits[i][2] + fruits[i][4]) / 2)
        current_fruit_area = abs((fruits[i][3] - fruits[i][1]) * (fruits[i][4] - fruits[i][2]))
        for j in range(len(combined_previous_fruits)):
            if combined_previous_fruits[j][0] == fruits[i][0]:
                previous_fruit_center = ((combined_previous_fruits[j][1] + combined_previous_fruits[j][3]) / 2, 
                                            (combined_previous_fruits[j][2] + combined_previous_fruits[j][4]) / 2)
                previous_fruit_area = abs((combined_previous_fruits[j][3] - combined_previous_fruits[j][1]) * 
                                            (combined_previous_fruits[j][4] - combined_previous_fruits[j][2]))
                center_distance = ((current_fruit_center[0] - previous_fruit_center[0]) ** 2 + 
                                    (current_fruit_center[1] - previous_fruit_center[1]) ** 2) ** 0.5
                area_difference = abs(current_fruit_area - previous_fruit_area)

                if center_distance <= (centre_threshold * 1.414) and area_difference <= area_threshold:
                    fruits[i][5] = combined_previous_fruits[j][5]
                    if int(fruits[i][0]) == 0:  # Yellow fruit
                        if int(combined_previous_fruits[j][5]) > yellow_id_max:
                            yellow_id_max = combined_previous_fruits[j][5]
                    if int(fruits[i][0]) == 1:  # Red fruit
                        if int(combined_previous_fruits[j][5]) > red_id_max:
                            red_id_max = combined_previous_fruits[j][5]

        # Assign new IDs for new fruits
        for i, fruit in enumerate(fruits):
            if fruit[5] is None:
                if int(fruit[0]) == 0:  # Yellow fruit
                    yellow_id_max += 1
                    fruits[i][5] = yellow_id_max
                if int(fruit[0]) == 1:  # Red fruit
                    red_id_max += 1
                    fruits[i][5] = red_id_max

    # Update previous_frame_fruits and two_frames_ago_fruits
    previous_frames_fruits.pop(0)
    previous_frames_fruits.append([fruit[:] for fruit in fruits])

    return fruits, camera_image
