import math
import numpy as np
from transformations import euler_from_quaternion

def latlon_to_local(ref_pos, lat, lon, alt):
    # WGS84 ellipsoid constants
    a = 6378137.0  # major semi-axis in meters
    f = 1 / 298.257223563  # flattening
    b = a * (1 - f)  # minor semi-axis

    lat0, lon0, alt0 = ref_pos

    # Convert reference latitude and longitude to radians
    lat0_rad = math.radians(lat0)
    lon0_rad = math.radians(lon0)
    lat_rad = math.radians(lat)
    lon_rad = math.radians(lon)

    # Prime vertical radius of curvature
    def N(lat):
        return a / math.sqrt(1 - (f * (2 - f)) * math.sin(lat) ** 2)

    # Convert to ECEF coordinates
    def geodetic_to_ecef(lat, lon, alt):
        N_val = N(lat)
        X = (N_val + alt) * math.cos(lat) * math.cos(lon)
        Y = (N_val + alt) * math.cos(lat) * math.sin(lon)
        Z = (b ** 2 / a ** 2 * N_val + alt) * math.sin(lat)
        return np.array([X, Y, Z])

    ecef_ref = geodetic_to_ecef(lat0_rad, lon0_rad, alt0)
    ecef_target = geodetic_to_ecef(lat_rad, lon_rad, alt)

    # Compute local ENU coordinates
    delta_ecef = ecef_target - ecef_ref

    # Rotation matrix from ECEF to ENU
    R = np.array([
        [-math.sin(lon0_rad), math.cos(lon0_rad), 0],
        [-math.sin(lat0_rad) * math.cos(lon0_rad), -math.sin(lat0_rad) * math.sin(lon0_rad), math.cos(lat0_rad)],
        [math.cos(lat0_rad) * math.cos(lon0_rad), math.cos(lat0_rad) * math.sin(lon0_rad), math.sin(lat0_rad)]
    ])

    enu_coords = R @ delta_ecef

    # Adjust to desired frame: front ahead (Y), left-right (X), up-down (Z)
    adjusted_x = enu_coords[0]  # North to front
    adjusted_y = enu_coords[1]  # East to left-right
    adjusted_z = enu_coords[2]  

    return adjusted_x, adjusted_y, adjusted_z

def angletolocal(imu_msg):
    # NED north - x
    # NED east - y
    # NED down - z
    orientation_list = [imu_msg.orientation.x, imu_msg.orientation.y, imu_msg.orientation.z, imu_msg.orientation.w]
    roll, pitch, yaw = euler_from_quaternion(orientation_list)
    # Convert radians to degrees
    roll = math.degrees(roll)
    pitch = math.degrees(pitch)
    yaw = math.degrees(yaw)

    roll = roll
    pitch = -pitch
    
    yaw = -(yaw - 90)
    if yaw > 180:
        yaw = yaw - 360
    return roll, pitch , yaw
    
def functiond(gps_msg, imu_msg,initial_coord_gps):
    # 0: GPS , 1: IMU
    reference_position = (initial_coord_gps.latitude, initial_coord_gps.longitude, initial_coord_gps.altitude)
    lat = gps_msg.latitude
    lon = gps_msg.longitude
    alt = gps_msg.altitude
    
    adjusted_x, adjusted_y, adjusted_z = latlon_to_local(reference_position, lat, lon, alt)
    
    roll,pitch,yaw = angletolocal(imu_msg)
    ###
    # x - East
    # Y - North
    # Z - Up
    ### 
    
    # Print the local coordinates and orientation
    result = [adjusted_x, adjusted_y, adjusted_z, roll, pitch, yaw]
    result = np.array(result, dtype=np.float16)
    return result
