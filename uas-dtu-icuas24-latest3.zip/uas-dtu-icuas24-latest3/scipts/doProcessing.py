import fruitdetection
import pcltoimg
import local_location
import processfruit
import livestream
import mapping
import time
import sys
import os

count_y = None
count_r = None
def runProcess(pcl_msg, img_msg, gps_msg, imu_msg,model,initial_coord_gps):
    camera_image = None
    display_data = None
    global count_r,count_y
    
    try:
        fruits,camera_image = fruitdetection.detect_fruit(img_msg,model)
        if fruits is not None:
            fruitcoordinates,labels = pcltoimg.lidarToImage(pcl_msg,camera_image,fruits)
            if fruitcoordinates is not None:
                current_location_local = local_location.functiond(gps_msg,imu_msg,initial_coord_gps)
                global_coordinates = mapping.map(current_location_local,fruitcoordinates)
                display_data,count_y,count_r = processfruit.processing(global_coordinates,labels,camera_image)  
                livestream.streaming(camera_image,display_data, img_msg,count_y,count_r)
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print(exc_type,exc_tb.tb_lineno,fname)
        print(e)    
        
    
   