import math
import numpy as np



def euler_to_rotation_matrix(current_location_local):

    ### angle transformation
    roll = current_location_local[3]
    pitch = current_location_local[4]
    yaw = current_location_local[5]
    roll = math.radians(roll)
    pitch = math.radians(pitch)
    yaw = math.radians(yaw)

    # pitch
    R_east = np.array([
        [1, 0, 0],
        [0, np.cos(pitch), -np.sin(pitch)],
        [0, np.sin(pitch), np.cos(pitch)]
    ],dtype=np.float16)
    
    # roll
    R_north = np.array([
        [np.cos(roll), 0, np.sin(roll)],
        [0, 1, 0],
        [-np.sin(roll), 0, np.cos(roll)]
    ],dtype=np.float16)
    
    yaw = -yaw
    # yaw (UP) - Z axis
    R_up = np.array([
        [np.cos(yaw), -np.sin(yaw), 0],
        [np.sin(yaw), np.cos(yaw), 0],
        [0, 0, 1]
    ],dtype=np.float16)
    
    return [R_east,R_north,R_up]

def transform_lidar_points(current_location_local, lidar_points):
    lidar_points = lidar_points.T
    # Get the rotation matrix
    rotation_matrix = euler_to_rotation_matrix(current_location_local)
    
    # Transform each LiDAR point
    transformed_points = []
    transformed_points = lidar_points
    transformed_points = np.dot(rotation_matrix[0], lidar_points)
    transformed_points = np.dot(rotation_matrix[1], transformed_points)
    transformed_points = np.dot(rotation_matrix[2], transformed_points)
  
    return transformed_points

def translation(current_location_local, transformed_points):

    east = current_location_local[0]
    north = current_location_local[1]
    up = current_location_local[2]
   
    transformed_points[0] = transformed_points[0] + east
    transformed_points[1] = transformed_points[1] + north
    transformed_points[2] = transformed_points[2] + up
    return transformed_points

def map(current_location_local,fruitcoordinates):
    global_coordinates = []
    Rotated_lidar_points = transform_lidar_points(current_location_local, fruitcoordinates)
    global_coordinates = translation(current_location_local, Rotated_lidar_points)
    global_coordinates = global_coordinates.T
    
    #downsampling
    global_coordinates = global_coordinates[::1]
   
    global_coordinates = np.array(global_coordinates, dtype=np.float16)
    return global_coordinates