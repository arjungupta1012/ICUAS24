import rospy
from sensor_msgs.msg import PointCloud2, CompressedImage, NavSatFix, Imu
from message_filters import ApproximateTimeSynchronizer, Subscriber
import time 
from concurrent.futures import ThreadPoolExecutor
import doProcessing
from ultralytics import YOLO

# Loading model
model = YOLO("v8n_best.pt")
executor = ThreadPoolExecutor(max_workers=1)

intial_coord_bool = False
initial_coord_gps = None

initial_camera_time = None
initial_lidar_time = None
initial_imu_time = None
initial_gps_time = None
camera_time_offset = None
imu_time_offset = None
gps_time_offset = None


pub_image = rospy.Publisher('/modified_image', CompressedImage, queue_size=10)
pub_imu = rospy.Publisher('/imu/data', Imu, queue_size=10)
pub_gps = rospy.Publisher('/global_position/global', NavSatFix, queue_size=10)

def process_and_publish_image(pcl_msg, img_msg, gps_msg, imu_msg):
    
    global intial_coord_bool, initial_coord_gps
    if intial_coord_bool == False:
        initial_coord_gps = gps_msg
        intial_coord_bool = True
    
    if pcl_msg is not None and img_msg is not None  and imu_msg is not None and gps_msg is not None:
        executor.submit(doProcessing.runProcess, pcl_msg, img_msg,gps_msg, imu_msg,model,initial_coord_gps)
    else:
        print("One of the messages is None")
    
def camera_callback(msg):
    global initial_camera_time
    if initial_camera_time is None:
        initial_camera_time = msg.header.stamp
        rospy.loginfo(f"Initial Camera timestamp: {initial_camera_time.to_sec()}")

def lidar_callback(msg):
    global initial_lidar_time
    if initial_lidar_time is None:
        initial_lidar_time = msg.header.stamp
        rospy.loginfo(f"Initial LiDAR timestamp: {initial_lidar_time.to_sec()}")

def imu_callback(msg):
    global initial_imu_time
    if initial_imu_time is None:
        initial_imu_time = msg.header.stamp
        rospy.loginfo(f"Initial IMU timestamp: {initial_imu_time.to_sec()}")

def gps_callback(msg):
    global initial_gps_time
    if initial_gps_time is None:
        initial_gps_time = msg.header.stamp
        rospy.loginfo(f"Initial GPS timestamp: {initial_gps_time.to_sec()}")

def image_callback(image_msg):
    original_timestamp = image_msg.header.stamp
    new_timestamp = original_timestamp + rospy.Duration.from_sec(camera_time_offset)
    modified_msg = image_msg
    modified_msg.header.stamp = new_timestamp 
    pub_image.publish(modified_msg)

def imu_callback_new(imu_msg):
    original_timestamp = imu_msg.header.stamp
    new_timestamp = original_timestamp + rospy.Duration.from_sec(imu_time_offset)
    new_imu_msg = imu_msg
    new_imu_msg.header.stamp = new_timestamp
    pub_imu.publish(new_imu_msg)

def gps_callback_new(gps_msg):
    original_timestamp = gps_msg.header.stamp
    new_timestamp = original_timestamp + rospy.Duration.from_sec(gps_time_offset)
    new_gps_msg = gps_msg
    new_gps_msg.header.stamp = new_timestamp
    pub_gps.publish(new_gps_msg)

def main():
    global camera_time_offset
    global imu_time_offset
    global gps_time_offset
    
    rospy.init_node('lidar_image_processor')
 
    lidar_sub = rospy.Subscriber('/velodyne_points', PointCloud2, lidar_callback)
    camera_sub = rospy.Subscriber('/camera/color/image_raw/compressed', CompressedImage,camera_callback)
    imu_sub2 = rospy.Subscriber('/hawkblue/mavros/imu/data', Imu, imu_callback)
    gps_sub2 = rospy.Subscriber('/hawkblue/mavros/global_position/global', NavSatFix, gps_callback)
    while initial_camera_time is None or initial_lidar_time is None or initial_imu_time is None or initial_gps_time is None:
        rospy.sleep(0.01)
    camera_time_offset = (initial_lidar_time - initial_camera_time).to_sec()
    imu_time_offset = (initial_lidar_time - initial_imu_time).to_sec()
    gps_time_offset = (initial_lidar_time - initial_gps_time).to_sec()
    camera_sub.unregister()
    lidar_sub.unregister()
    imu_sub2.unregister()
    gps_sub2.unregister()
    print("Starting Script - UAS DTU")
    rospy.Subscriber('/camera/color/image_raw/compressed', CompressedImage,image_callback)
    rospy.Subscriber('hawkblue/mavros/imu/data', Imu, imu_callback_new)
    rospy.Subscriber('hawkblue/mavros/global_position/global', NavSatFix, gps_callback_new)
    pcl_sub = Subscriber('/velodyne_points', PointCloud2)
    new_img_sub = Subscriber('/modified_image', CompressedImage)
    new_gps_sub = Subscriber('/global_position/global', NavSatFix)
    new_imu_sub = Subscriber('/imu/data', Imu)
    
    # Synchronize messages from both topics based on their timestamps
    sync = ApproximateTimeSynchronizer([pcl_sub, new_img_sub,new_gps_sub, new_imu_sub], queue_size=500, slop=0.02)
    sync.registerCallback(process_and_publish_image)

    rospy.spin()

if __name__ == '__main__':
    main()
