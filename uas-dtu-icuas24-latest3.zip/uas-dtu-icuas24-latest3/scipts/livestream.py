import numpy as np
import rospy
from sensor_msgs.msg import  Image
from cv_bridge import CvBridge, CvBridgeError
import numpy as np
import cv2
import os
import sensor_msgs.point_cloud2 as pc2
import math
from std_msgs.msg import Header
from std_msgs.msg import Int32
import time
processed_image_pub2 = rospy.Publisher('/fruit_detections', Image, queue_size=10,latch=True)
redcount_publisher = rospy.Publisher('/red_fruit_count', Int32, queue_size=10 ,latch=True)
yellowcount_publisher = rospy.Publisher('/yellow_fruit_count', Int32, queue_size=10, latch=True)

def streaming(camera_image,display_data, image_msg,count_y,count_r):
    msg_yellow = Int32()
    msg_red = Int32()
    msg_yellow.data = count_y
    msg_red.data = count_r
    yellowcount_publisher.publish(msg_yellow)
    redcount_publisher.publish(msg_red)
    
    bridge = CvBridge() 
    
    if camera_image is not None:
        if display_data is None:
            pass
        else:
            for fruit in display_data:
                if fruit[0]==0:
                    continue
                [x1,y1,x2,y2] = fruit[2]
                x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
                if (fruit[1]) == '0':
                    color = "Yellow"
                else:
                    color = "Red"
                label = f"{color}{fruit[0]}"
                camera_image_n = fruit[-1]
                cv2.rectangle(camera_image_n,(x1,y1),(x2,y2),color=(0,255,0),thickness=2)
                cv2.putText(camera_image_n, label, (x1, y1 - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)
                try:
                    processed_image_msg2 = bridge.cv2_to_imgmsg(camera_image_n, "bgr8")
                    processed_image_msg2.header = image_msg.header 
                    time.sleep(0.1)
                    processed_image_pub2.publish(processed_image_msg2)
                    
                except CvBridgeError as e:
                    print(e)
        
    