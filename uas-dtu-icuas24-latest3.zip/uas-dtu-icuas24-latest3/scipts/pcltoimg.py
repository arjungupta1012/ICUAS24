import rospy
import numpy as np
import cv2
import sensor_msgs.point_cloud2 as pc2
import math
import time
from cv_bridge import CvBridge

bridge = CvBridge()

def lidarToImage(lidar_msg, camera_image,fruits):
    fruitcoordinates = []
    labels = []
    intrinsic_matrix = np.array([[614.76598009, 0, 317.533],
                              [0, 612.93157203, 232.2761],
                              [0, 0, 1]])

    theta = np.radians(10)
    rotation_matrix = np.array([[np.cos(theta), 0, np.sin(theta)],
                                [0, 1, 0],
                                [-np.sin(theta), 0, np.cos(theta)]])
    translation = np.array([[-0.083],
                            [0.045],
                            [-0.126]])


    # Extrinsic matrix
    extrinsic_matrix = np.concatenate((rotation_matrix, translation), axis=1)

    # Your camera image dimensions here
    camera_image_width = 640
    camera_image_height = 480
    
    # Convert lidar message to point cloud
    lidar_points_accumulated_numpy = np.array(list(pc2.read_points(lidar_msg, field_names=("x", "y", "z"), skip_nans=True)), dtype=np.float16)
    
    # Reducing lidar points
    with np.errstate(divide='ignore', over='ignore', invalid='ignore'):
        mask = (lidar_points_accumulated_numpy[:, 0] > 0) & \
            (np.sqrt(np.sum(lidar_points_accumulated_numpy**2, axis=1)) <= 7) & \
            (lidar_points_accumulated_numpy[:,1]/lidar_points_accumulated_numpy[:,0] >= -0.64940759319) & \
            (lidar_points_accumulated_numpy[:,1]/lidar_points_accumulated_numpy[:,0] <= 0.64940759319) & \
                (lidar_points_accumulated_numpy[:,2]/lidar_points_accumulated_numpy[:,0] <= 0.5) & \
                    (lidar_points_accumulated_numpy[:,2]/lidar_points_accumulated_numpy[:,0] >= -0.5)
         

    # Apply the mask to filter the points
    lidar_points_accumulated_filtered = lidar_points_accumulated_numpy[mask]
    lidar_points_accumulated = lidar_points_accumulated_filtered

    # Process and save image using lidar_points data
    if camera_image is not None and lidar_points_accumulated.shape[0] != (0,0) :
        
        # changing lidar points z axis
        lidar_points_accumulated[:,2] =  0 - lidar_points_accumulated[:,2]
        array_ones = np.ones((lidar_points_accumulated.shape[0],1))
        lidar_points_accumulated_concat = np.transpose(np.concatenate((lidar_points_accumulated,array_ones),axis=1),axes=[1,0])

        transformed_points = np.dot(extrinsic_matrix, lidar_points_accumulated_concat)
        backtrack_points = transformed_points.copy()
        temp = transformed_points[0,:].copy()
        transformed_points[0,:] = transformed_points[1,:]
        transformed_points[1,:] = transformed_points[2,:]
        transformed_points[2,:] = temp
    
        transformed_point_homogeneous = np.dot(intrinsic_matrix, transformed_points)
        transformed_point_homogeneous /= (transformed_point_homogeneous[2,:])
        
        u = transformed_point_homogeneous[0,:]
        v = transformed_point_homogeneous[1,:]

        for fruit in fruits:
            x1, y1, x2, y2 = fruit[1], fruit[2], fruit[3], fruit[4]
            centre = [(x1+x2)//2, (y1+y2)//2]
            radius = int((math.sqrt((x2 - centre[0])**2 + (y2 - centre[1])**2 ))//3)
            mask = ((u >= x1) & (u <= x2) & (camera_image_height -v >= y1) & (camera_image_height -v <= y2)) & \
                ((u >= 0)&(u <= 640)&(camera_image_height -v >= 0)&(camera_image_height -v <= 480)) & \
                    (((u - centre[0])**2)+(camera_image_height - v - centre[1])**2 <= radius**2)
              
            coord = []
            for i in np.where(mask)[0]:
                coord.append(list(backtrack_points[:,i]))
                labels.append([fruit[0],[x1,y1,x2,y2],fruit[5]])
            fruitcoordinates.extend(coord)
        
        
        fruitcoordinates = np.array(fruitcoordinates,dtype=np.float16)
        if fruitcoordinates.shape[0] != 0:
            fruitcoordinates = fruitcoordinates.T
            temp = fruitcoordinates[0,:].copy()
            fruitcoordinates[0,:] = fruitcoordinates[1,:]
            fruitcoordinates[1,:] = temp
            fruitcoordinates = fruitcoordinates.T
        else:
            fruitcoordinates = None
            labels = None
        return fruitcoordinates,labels
    return None,None

        

